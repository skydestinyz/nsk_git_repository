package com.soul.services.impl;

import com.soul.entities.AssignmentResult;
import com.soul.entities.TeamSkill;
import com.soul.repositories.AssignmentResultRepository;
import com.soul.services.AssignmentResultService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AssignmentResultServiceImpl implements AssignmentResultService {


    @Autowired
    AssignmentResultRepository assignmentResultRepository;

    private final Logger log = LoggerFactory.getLogger(AssignmentResultServiceImpl.class);

    @Transactional
    public void saveAsJson(TeamSkill teamSkill) {
        log.info("Saving result as Json");
        AssignmentResult assignmentResult = new AssignmentResult();
        assignmentResult.setJasonResult(teamSkill.toString());
        assignmentResultRepository.save(assignmentResult);
    }


}
