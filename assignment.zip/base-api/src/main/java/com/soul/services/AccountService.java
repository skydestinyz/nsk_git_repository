package com.soul.services;

import com.soul.entities.Account;

public interface AccountService {
    Account findByUsername(String username);

    Account registerUser(Account account);
}
