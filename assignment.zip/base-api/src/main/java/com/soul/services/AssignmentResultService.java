package com.soul.services;

import com.soul.entities.TeamSkill;

public interface AssignmentResultService {

    void saveAsJson(TeamSkill teamSkill);

}
