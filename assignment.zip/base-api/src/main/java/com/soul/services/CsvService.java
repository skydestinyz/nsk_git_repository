package com.soul.services;

import org.springframework.web.multipart.MultipartFile;

public interface CsvService {

    Boolean extractData(MultipartFile attachment, String fileType);


    void readData();

}
