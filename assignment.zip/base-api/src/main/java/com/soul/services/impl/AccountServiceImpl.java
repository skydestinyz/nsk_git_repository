package com.soul.services.impl;

import com.soul.entities.Account;
import com.soul.repositories.AccountRepository;
import com.soul.services.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Account findByUsername(String username) {
        Optional<Account> account = accountRepository.findByUsernameReturnOptional(username);

        return account.isPresent() ? account.get() : null;
    }


    public Account registerUser(Account account) {
        if (Optional.ofNullable(account.getNewPassword()).isPresent())
            account.setPassword(passwordEncoder.encode(account.getNewPassword()));
        return accountRepository.save(account);
    }

}
