package com.soul.services.impl;

import com.soul.entities.Task;
import com.soul.entities.Team;
import com.soul.entities.TeamSkill;
import com.soul.repositories.TaskRepository;
import com.soul.repositories.TeamRepository;
import com.soul.repositories.TeamSkillRepository;
import com.soul.services.CsvService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class CsvServiceImpl implements CsvService {

    @Autowired
    TeamRepository teamRepository;

    @Autowired
    TeamSkillRepository teamSkillRepository;

    @Autowired
    TaskRepository taskRepository;

    private final Logger log = LoggerFactory.getLogger(CsvServiceImpl.class);

    @Transactional
    public Boolean extractData(MultipartFile attachment, String fileType) {

        int successCount = 0;
        Boolean resultFlag = Boolean.FALSE;

        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(attachment.getBytes());
            Workbook workbook = new XSSFWorkbook(byteArrayInputStream);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();
            String filePath = "";

            if (fileType.equals("TEAM")) {
                List<Team> teams = new ArrayList<>();
                while (iterator.hasNext()) {
                    Row currentRow = iterator.next();
                    log.debug("Current row : " + currentRow.getRowNum());
                    Team team = new Team();
                    team.setTeamId(convertExcelCellToString(currentRow.getCell(0)));
                    teamRepository.save(team);
                    successCount++;
                }
                filePath = "c:\\csv_files\\team.csv";
            } else if (fileType.equals("TEAM_SKILL")) {
                List<TeamSkill> teamSkills = new ArrayList<>();
                while (iterator.hasNext()) {
                    Row currentRow = iterator.next();
                    log.debug("Current row : " + currentRow.getRowNum());
                    TeamSkill teamSkill = new TeamSkill();
                    teamSkill.setTeamId(convertExcelCellToString(currentRow.getCell(0)));
                    teamSkill.setSkill(convertExcelCellToString(currentRow.getCell(1)));
                    teamSkillRepository.save(teamSkill);
                    successCount++;
                }
                filePath = "c:\\csv_files\\team_skill.csv";
            } else {
                while (iterator.hasNext()) {
                    Row currentRow = iterator.next();
                    log.debug("Current row : " + currentRow.getRowNum());
                    Task task = new Task();
                    task.setTaskId(convertExcelCellToString(currentRow.getCell(0)));
                    task.setSkill(convertExcelCellToString(currentRow.getCell(1)));
                    taskRepository.save(task);
                    successCount++;
                }
                filePath = "c:\\csv_files\\task.csv";
            }
            if (successCount > 0) {
                File file = new File(filePath);
                log.info("If upload success, delete related file");
                file.delete();
                resultFlag = Boolean.TRUE;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
            log.debug(ex.getMessage());
        }
        return resultFlag;
    }

    public static String convertExcelCellToString(Cell currentCell) {
        if (currentCell != null) {
            if (currentCell.getCellType() == 0) {
                Double cellDouble = currentCell.getNumericCellValue();
                return String.valueOf(cellDouble.intValue());
            } else if (currentCell.getCellType() == 1) {
                return currentCell.getStringCellValue();
            } else {
                return null;
            }
        } else {
            return null;
        }
    }


    public void readData() {

        try {
            File file = new File("c:\\csv_files\\team.csv");
            //init array with file length
            byte[] bytesArray = new byte[(int) file.length()];

            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytesArray);
            Workbook workbook = new XSSFWorkbook(byteArrayInputStream);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();
            String filePath = "";

            List<Team> teams = new ArrayList<>();
            while (iterator.hasNext()) {
                Row currentRow = iterator.next();
                log.debug("Current row : " + currentRow.getRowNum());
               /* Team team = new Team();
                team.setTeamId(convertExcelCellToString(currentRow.getCell(0)));
                teamRepository.save(team);
*/
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
            log.debug(ex.getMessage());
        }
    }


}
