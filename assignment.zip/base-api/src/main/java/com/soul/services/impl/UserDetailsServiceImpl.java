package com.soul.services.impl;

import com.soul.entities.Account;
import com.soul.entities.Role;
import com.soul.enums.EnumAccountStatus;
import com.soul.repositories.RoleRepository;
import com.soul.services.AccountService;
import com.soul.utils.Global;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author SK
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private AccountService accountService;

    @Autowired
    private RoleRepository roleRepository;


    /**
     * Create Default Master data and Users
     */
    @PostConstruct
    protected void initialize() throws Exception {
        // Create sample roles
        if (roleRepository.findByName(Global.ROLE_SUPER_ADMIN) == null) {
            logger.debug("Creating default admin role ...");
            Role roleAdmin = new Role();
            roleAdmin.setName(Global.ROLE_SUPER_ADMIN);
            roleAdmin.setRestricted(true);
            roleRepository.save(roleAdmin);
        }
        if (roleRepository.findByName("ROLE_USER") == null) {
            Role roleUser = new Role();
            roleUser.setName("ROLE_USER");
            roleRepository.save(roleUser);
        }
        // Create default users
        if (accountService.findByUsername("admin") == null) {
            logger.debug("Creating default admin account ...");
            Account adminAccount = new Account();
            adminAccount.setFullName("Administrator");
            adminAccount.setEmail("admin@rbtsb.com");
            adminAccount.setUsername("admin");
            adminAccount.setNewPassword("admin");
            adminAccount.setForceChangePassword(false);
            adminAccount.setRole(roleRepository.findByName("ROLE_SUPER_ADMIN"));
            adminAccount.setStatus(EnumAccountStatus.ACTIVE);
            adminAccount.setRestricted(true);
            accountService.registerUser(adminAccount);
        }

        // Create default users
        if (accountService.findByUsername("demo") == null) {
            logger.debug("Creating demo account ...");
            Account demoAccount = new Account();
            demoAccount.setFullName("demo");
            demoAccount.setEmail("demo@rbtsb.com");
            demoAccount.setUsername("demo");
            demoAccount.setNewPassword("demo");
            demoAccount.setForceChangePassword(false);
            demoAccount.setRole(roleRepository.findByName("ROLE_USER"));
            demoAccount.setStatus(EnumAccountStatus.ACTIVE);
            demoAccount.setRestricted(false);
            accountService.registerUser(demoAccount);
        }

    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return Optional.ofNullable(accountService.findByUsername(username)).map(this::createUser).orElseThrow(() -> new UsernameNotFoundException("user not found"));
    }


    private User createUser(Account account) {
        return new User(account.getUsername(), account.getPassword(), createAuthority(account));
    }


    private List<GrantedAuthority> createAuthority(Account account) {
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        Role role = account.getRole();
        if (role != null) {
            authorities.add(new SimpleGrantedAuthority(role.getName()));

          /*  List<Module> modules = moduleRepository.findByRoleId(role.getId());
            for (Module module : modules)
                authorities.add(new SimpleGrantedAuthority(module.getName()));

            List<Permission> permissions = permissionRepository.findByRoleId(role.getId());
            for (Permission permission : permissions)
                authorities.add(new SimpleGrantedAuthority(permission.getName()));

            List<Action> actions = actionRepository.findByRoleId(role.getId());
            for (Action action : actions)
                authorities.add(new SimpleGrantedAuthority(action.getName()));*/

            return authorities;
        }

        return null;
    }



}
