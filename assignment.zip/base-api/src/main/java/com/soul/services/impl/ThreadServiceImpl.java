package com.soul.services.impl;

import com.soul.services.CsvService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
public class ThreadServiceImpl extends Thread {


    @Autowired
    CsvService csvService;

    private final Logger log = LoggerFactory.getLogger(ThreadServiceImpl.class);


    @Transactional
    public Boolean managingThread(MultipartFile attachment, String fileType) {

        if(fileType.equals("TEAM")) {
            ThreadServiceImpl teamFileService = new ThreadServiceImpl();
            teamFileService.setDaemon(Boolean.TRUE);
            teamFileService.start();
        }else if(fileType.equals("TEAM_SKILL")){
            ThreadServiceImpl teamSkillFileService = new ThreadServiceImpl();
            teamSkillFileService.setDaemon(Boolean.TRUE);
            teamSkillFileService.start();
        }else{
            ThreadServiceImpl taskFileService = new ThreadServiceImpl();
            taskFileService.setDaemon(Boolean.TRUE);
            taskFileService.start();
        }

        log.info("Thread Name :: " + Thread.currentThread().getName());
        log.info("Thread ID :: " + Thread.currentThread().getId());

        // call for extra data service and return result
        return csvService.extractData(attachment,fileType);
    }
}
