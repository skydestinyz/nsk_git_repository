package com.soul.repositories;

import com.soul.entities.Task;

public interface TaskRepository extends BaseEntityRepository<Task> {

}
