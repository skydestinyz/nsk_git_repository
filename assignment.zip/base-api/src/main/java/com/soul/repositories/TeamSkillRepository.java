package com.soul.repositories;

import com.soul.entities.TeamSkill;

public interface TeamSkillRepository extends BaseEntityRepository<TeamSkill> {

}
