package com.soul.repositories;

import com.soul.entities.AssignmentResult;

public interface AssignmentResultRepository extends BaseEntityRepository<AssignmentResult> {
}
