package com.soul.repositories;

import com.soul.entities.Account;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface AccountRepository extends MasterEntityRepository<Account> {

    @Query("select a from Account a where a.deleted = false and a.username = ?1")
    Optional<Account> findByUsernameReturnOptional(String username);

}
