package com.soul.repositories;

import com.soul.entities.Team;

public interface TeamRepository extends BaseEntityRepository<Team> {



}
