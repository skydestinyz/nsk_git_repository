package com.soul.repositories;

import com.soul.entities.Role;

public interface RoleRepository extends MasterEntityRepository<Role> {

    Role findByName(String name);

}
