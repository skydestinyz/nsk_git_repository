package com.soul.repositories;


import com.soul.entities.BaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * Override existing JPA Spring Data methods
 *
 * @param <T>
 * @author SK
 */
@NoRepositoryBean
public interface BaseEntityRepository<T extends BaseEntity> extends JpaRepository<T, String>, JpaSpecificationExecutor<T> {


}
