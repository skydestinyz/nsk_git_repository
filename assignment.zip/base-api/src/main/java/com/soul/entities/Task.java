package com.soul.entities;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TASK")
public class Task extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7509737276421745100L;

    @Column(name = "TASK_ID", nullable = false)
    private String taskId;

    @Column(name = "SKILL")
    private String skill;

}

