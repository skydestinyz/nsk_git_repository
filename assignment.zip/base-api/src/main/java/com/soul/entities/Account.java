package com.soul.entities;


import com.soul.enums.EnumAccountStatus;
import com.soul.utils.Global;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Account Entity
 *
 * @author SK
 */
@Data
@EqualsAndHashCode(callSuper = false, exclude = {"role"})
@Entity
@Table(name = "accounts", indexes = {
        @Index(name="account_index", columnList = "id, username, email")
})
@ToString(exclude = {"role", "password"})
public class Account extends MasterEntity implements Serializable {

    private static final long serialVersionUID = -77806658444851291L;

    @Column(name = "username", nullable = false, length = Global.VARCHAR32)
    private String username;

    @Column(name = "password", nullable = false, length = Global.VARCHAR255)
    private String password;

    @Column(name = "email", nullable = false, length = Global.VARCHAR64)
    private String email;

    @Column(name = "full_name", nullable = false, length = Global.VARCHAR255)
    private String fullName;

    @Column(name = "account_non_expired")
    private Boolean accountNonExpired = true;

    @Column(name = "account_non_locked")
    private Boolean accountNonLocked = true;

    @Column(name = "credentials_non_expired")
    private Boolean credentialsNonExpired = true;

    @Column(name = "enabled")
    private Boolean enabled = true;

    @Column(name = "login_attempts")
    private Integer loginAttempts = 0;

    @Column(name = "force_change_password")
    private Boolean forceChangePassword = true;

    @Size(max = 20)
    @Column(name = "reset_token", length = 20)
    private String resetToken;

    @Column(name = "request_reset_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestResetDate;

    @Column(name = "reset_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date resetDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn
    @NotNull
    private Role role;


    @Enumerated(value = EnumType.STRING)
    @Column(name = "STATUS", nullable = false)
    private EnumAccountStatus status = EnumAccountStatus.ACTIVE;

    @Transient
    private List<String> authorities;

    @Transient
    private String newPassword;

    public int getLoginAttempts() {
        return loginAttempts != null ? loginAttempts : 0;
    }

    public EnumAccountStatus getStatus() {
        return status != null ? status : EnumAccountStatus.ACTIVE;
    }

    public Account() {
    }

    public Account(String username, String password, String email, String fullName, Role role) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
    }

    public Date getRequestResetDate() {
        return requestResetDate != null ? (Date) requestResetDate.clone() : null;
    }

    public void setRequestResetDate(Date requestResetDate) {
        this.requestResetDate = requestResetDate != null ? (Date) requestResetDate.clone() : null;
    }

    public Date getResetDate() {
        return resetDate != null ? (Date) resetDate.clone() : null;
    }

    public void setResetDate(Date resetDate) {
        this.resetDate = resetDate != null ? (Date) resetDate.clone() : null;
    }

}
