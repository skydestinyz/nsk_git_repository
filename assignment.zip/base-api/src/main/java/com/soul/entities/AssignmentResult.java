package com.soul.entities;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;


@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "ASSIGNMENT_RESULT")
public class AssignmentResult extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7509737276421745100L;


    @Column(name = "JSON_RESULT", nullable = false)
    private String jasonResult;

}

