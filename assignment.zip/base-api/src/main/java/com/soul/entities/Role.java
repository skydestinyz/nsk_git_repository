package com.soul.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.soul.utils.Global;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Role Entity
 *
 * @author SK
 */
@Data
@EqualsAndHashCode(callSuper = false, exclude = {"accounts"})
@Entity
@Table(name = "roles")
public class Role extends MasterEntity implements Serializable {

    @Column(name = "NAME", nullable = false, length = Global.VARCHAR255)
    private String name;

    @Column(name = "DESCRIPTION", length = Global.VARCHAR255)
    private String description;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "role")
    @JsonIgnore
    private Set<Account> accounts = new HashSet<Account>();

    @Transient
    public String getText(){
        return this.description;
    }

    public Role(){}

    public Role(String name) {
		this.name = name;
	}

	public Role(String name, String description) {
		this.name = name;
		this.description = description;
	}

}
