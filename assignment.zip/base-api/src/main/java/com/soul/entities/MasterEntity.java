
package com.soul.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.soul.dto.MasterEntityDTO;
import com.soul.utils.Global;
import com.soul.utils.SecurityContextUtil;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * MasterEntity entity which should be extends for all entity
 *
 * @author SK
 */

@Data
@EqualsAndHashCode(callSuper = false)
@MappedSuperclass
public abstract class MasterEntity extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 8766891123160277608L;

    @JsonIgnore
    @Column(name = "DELETED", nullable = false)
    private Boolean deleted = false;

    @Column(name = "ACTIVE", nullable = false)
    private Boolean active = true;

    @Version
    @Column(name = "NOC", nullable = false)
    private Integer noc = 0;

    @Column(name = "RESTRICTED", nullable = false)
    private Boolean restricted = false;

    @Column(name = "CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "CREATED_BY", nullable = false, length = Global.VARCHAR255)
    private String createdBy;

    @Column(name = "LAST_MODIFIED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @Column(name = "LAST_MODIFIED_BY", nullable = false, length = Global.VARCHAR255)
    private String lastModifiedBy;

    @PrePersist
    void onCreate() {
        this.setCreatedDate(new Date());
        this.setLastModifiedDate(new Date());
        this.setCreatedBy(SecurityContextUtil.getCurrentUsername());
        this.setLastModifiedBy(SecurityContextUtil.getCurrentUsername());
    }

    @PreUpdate
    void onUpdate() {
        this.setLastModifiedDate(new Date());
        this.setLastModifiedBy(SecurityContextUtil.getCurrentUsername());
    }

    @JsonIgnore
    public void setDTO(MasterEntityDTO masterEntityDTO) {
        super.setDTO(masterEntityDTO);
        this.deleted = StringUtils.isEmpty(masterEntityDTO.getDeleted()) ? this.deleted : masterEntityDTO.getDeleted();
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate != null ? (Date) createdDate.clone() : null;
    }

    public Date getCreatedDate() {
        return createdDate != null ? (Date) createdDate.clone() : null;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate != null ? (Date) lastModifiedDate.clone() : null;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate != null ? (Date) lastModifiedDate.clone() : null;
    }
}

