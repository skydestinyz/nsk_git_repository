package com.soul.controllers;

import com.soul.entities.TeamSkill;
import com.soul.services.AssignmentResultService;
import com.soul.services.impl.ThreadServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class HomeController {

    Logger log = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    ThreadServiceImpl threadServiceImpl;

    @Autowired
    AssignmentResultService assignmentResultService;


    @RequestMapping(value = "/api/excel-attachment", method = RequestMethod.POST)
    public ResponseEntity<?> uploadExcel(@PathVariable String fileType,
                                         @RequestParam MultipartFile attachment) {

        Boolean responseFlag = Boolean.FALSE;
        try {
            log.info("Rest api call for thread service");
            responseFlag = threadServiceImpl.managingThread(attachment, fileType);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ResponseEntity.ok(responseFlag);
    }


    @RequestMapping(value = "/api/save", method = RequestMethod.POST)
    public ResponseEntity<?> save(@RequestBody TeamSkill teamSkill) {

        Boolean responseFlag = Boolean.FALSE;
        try {
            log.info("Rest api call for thread service");
            assignmentResultService.saveAsJson(teamSkill);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ResponseEntity.ok(responseFlag);
    }

}