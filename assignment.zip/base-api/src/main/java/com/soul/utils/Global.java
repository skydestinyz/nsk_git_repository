package com.soul.utils;

/**
 * Constant Variables
 *
 * @author SK
 */
public interface Global {


    int VARCHAR255 = 255;
    int VARCHAR64 = 64;
    int VARCHAR32 = 32;
    String ROLE_SUPER_ADMIN = "ROLE_SUPER_ADMIN";

}
