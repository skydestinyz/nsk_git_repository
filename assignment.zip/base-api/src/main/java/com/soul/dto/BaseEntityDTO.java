package com.soul.dto;

import lombok.Data;

@Data
public class BaseEntityDTO {
    private String id;
}
