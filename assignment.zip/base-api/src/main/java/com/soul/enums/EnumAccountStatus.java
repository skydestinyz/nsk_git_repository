package com.soul.enums;

/**
 * Account Status
 *
 * @author SK
 */
public enum EnumAccountStatus {
	ACTIVE("Active"), INACTIVE("Inactive"), LOCKED("Locked");
	// Text to be display in the UI
	private String text;

	EnumAccountStatus(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
